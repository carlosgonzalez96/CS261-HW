################################
# CS 261 - Fall 2017
# Homework 0
# Name: Carlos Gonzalez
################################

def hello_world(val=''):
    print("Hello, World!")
    return 0
hello_world()